//>>built
define("dgrid/extensions/nls/cs/columnHider",{popupLabel:"Zobrazit nebo skr\u00fdt sloupce"});