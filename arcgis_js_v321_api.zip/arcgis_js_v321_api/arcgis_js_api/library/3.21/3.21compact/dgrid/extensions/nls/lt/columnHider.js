//>>built
define("dgrid/extensions/nls/lt/columnHider",{popupLabel:"Rodyti arba sl\u0117pti stulpelius"});