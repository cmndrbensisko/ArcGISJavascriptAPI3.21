//>>built
define("dgrid/extensions/nls/pt-br/columnHider",{popupLabel:"Mostrar ou ocultar colunas"});