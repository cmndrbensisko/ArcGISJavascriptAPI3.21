//>>built
define("dgrid/extensions/nls/ro/columnHider",{popupTriggerLabel:"Afi\u0219area sau ascunderea coloanelor",popupLabel:"Afi\u0219area sau ascunderea coloanelor"});