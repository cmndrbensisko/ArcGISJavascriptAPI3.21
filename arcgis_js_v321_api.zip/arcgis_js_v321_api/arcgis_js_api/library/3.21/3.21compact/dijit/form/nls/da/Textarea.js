//>>built
define("dijit/form/nls/da/Textarea",{iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"ramme om redigeringsomr\u00e5de"});