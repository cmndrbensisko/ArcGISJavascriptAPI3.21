//>>built
define("dijit/form/nls/zh-hk/ComboBox",{previousMessage:"\u524d\u4e00\u500b\u9078\u64c7\u9805",nextMessage:"\u5176\u4ed6\u9078\u64c7\u9805"});