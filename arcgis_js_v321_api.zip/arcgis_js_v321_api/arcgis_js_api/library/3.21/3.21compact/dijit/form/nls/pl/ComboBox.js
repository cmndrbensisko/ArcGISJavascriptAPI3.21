//>>built
define("dijit/form/nls/pl/ComboBox",{previousMessage:"Poprzednie wybory",nextMessage:"Wi\u0119cej wybor\u00f3w"});