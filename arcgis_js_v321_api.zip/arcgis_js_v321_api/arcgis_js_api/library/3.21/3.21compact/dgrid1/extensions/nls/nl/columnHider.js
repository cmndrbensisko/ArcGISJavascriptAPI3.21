//>>built
define("dgrid1/extensions/nls/nl/columnHider",{popupLabel:"Kolommen weergeven of verbergen"});