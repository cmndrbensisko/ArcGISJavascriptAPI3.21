//>>built
define("dgrid1/extensions/nls/pt-br/columnHider",{popupLabel:"Mostrar ou ocultar colunas"});