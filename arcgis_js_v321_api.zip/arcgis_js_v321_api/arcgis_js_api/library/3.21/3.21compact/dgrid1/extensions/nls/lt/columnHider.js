//>>built
define("dgrid1/extensions/nls/lt/columnHider",{popupLabel:"Rodyti arba sl\u0117pti stulpelius"});